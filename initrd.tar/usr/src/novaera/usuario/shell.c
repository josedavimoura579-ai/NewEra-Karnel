/*
 * ===========================================================================
 *  NovaEra - usuario/shell.c   (PID 3, anel 3)
 *  O shell é um programa comum: não enxerga a tela nem o teclado. Ele lê
 *  linhas do terminal (a entrada padrão), escreve no terminal (a saída
 *  padrão) e executa os programas que o servidor de arquivos guarda em
 *  /bin, ligando a entrada e a saída deles a pipes e arquivos:
 *
 *      ls /bin | cat         echo oi > /tmp/a         cat < /tmp/a
 * ===========================================================================
 */
#include "ulib.h"
#include "contas.h"
#include "sistema.h"      /* gerado de sistema.conf pelo build.sh */

/* O shell do boot é o PID 3. Uma cópia dele, o /bin/sh, roda como um
 * programa comum (o su e o login a chamam): esse sai com "sair" ou com
 * Ctrl+D, e ignora o Ctrl+C (que é para os comandos dele). */
static int do_boot;

/* O sistema instalado num disco: o GRUB passa "root=sda1" na linha de
 * boot. O shell do boot (PID 3) faz então o papel do "init" do Unix: monta
 * a raiz (/) daquele disco e chama o /bin/init de lá, que monta o resto
 * (/etc/montagens) e mostra o login. Se o init terminar, chama de novo:
 * nunca fica um shell do root aberto sem senha. Sem "root=" (no QEMU com
 * -kernel e -initrd, ou na ISO), o sistema roda da memória, como sempre. */
static int raiz_montada(void)
{
    char pasta[CAMINHO_MAX];
    for (u32 i = 0; montagem(i, pasta, 0, 0) == 0; i++)
        if (str_igual(pasta, "/")) return 1;
    return 0;
}

static void modo_init(void)
{
    msg_t m;
    sys_linha_boot(&m);
    const char *r = m.texto;
    while (*r && !(r[0] == 'r' && r[1] == 'o' && r[2] == 'o' && r[3] == 't' && r[4] == '=')) r++;
    if (!raiz_montada()) {
        if (!*r) return;                             /* sem root=: roda da memória */
        char nome[16];
        u32 k = 0;
        for (r += 5; *r && *r != ' ' && k + 1 < sizeof nome; r++) nome[k++] = *r;
        nome[k] = '\0';
        long dev = dispositivo_de(nome);
        escreve("[init] montando a raiz: ", COR(COR_CINZA_CLARO));
        escreve(nome, COR(COR_BRANCO));
        escreve(" em /\n", COR(COR_CINZA_CLARO));
        long e = dev < 0 ? ERRO_INVALIDO : montar_em((u32)dev, "/");
        if (e < 0) {
            escreve("[init] nao consegui montar a raiz: o sistema roda da memoria.\n\n", COR(COR_VERMELHO_CLARO));
            return;
        }
    }
    for (u32 vezes = 0; ; vezes++) {
        char *args[] = { "init", 0 };
        long pid = executar("/bin/init", args, 0, 0, 0, 0);
        if (pid < 0) {
            escreve("[init] o disco nao tem /bin/init: abrindo o shell do root.\n\n", COR(COR_VERMELHO_CLARO));
            return;
        }
        sys_esperar((u32)pid);
        if (vezes > 20) for (u32 t = sys_tempo(); sys_tempo() - t < 100; ) sys_ceder();  /* sem girar à toa */
    }
}

/* O nome de um usuário pelo uid (do /etc/passwd); "?" se não achar. */
static void nome_usuario(u32 uid, char *nome, u32 max)
{
    u32 tam;
    u8 *d = arq_carregar("/etc/passwd", &tam);
    conta_t c;
    char *t = d ? umalloc(tam + 1) : 0;
    if (t) { mem_copia(t, d, tam); t[tam] = 0; }
    if (t && conta_procura(t, 0, uid, &c)) str_copia(nome, c.nome, max);
    else num_texto(uid, nome);
    ufree(t);
    ufree(d);
}

static void escreve_coluna(const char *s, u32 largura, u8 cor)
{
    escreve(s, cor);
    for (u32 i = str_tam(s); i < largura; i++) escreve(" ", cor);
}

/* ---------------------------- Comandos internos --------------------------- */

static const char *const ESTADOS[] = {
    "livre", "pronto", "enviando", "recebendo", "morto", "esperando", "zumbi", "futex"
};
static const char *const EXCECOES[] = {
    "Divisao por zero", "Debug", "NMI", "Breakpoint", "Overflow",
    "Limite excedido", "Opcode invalido", "FPU indisponivel", "Falta dupla",
    "Segmento do coprocessador", "TSS invalido", "Segmento ausente",
    "Falha de pilha", "Protecao geral (GPF)", "Falha de pagina"
};

static void cmd_ajuda(void)
{
    const u8 c = COR(COR_AMARELO), d = COR(COR_CINZA_CLARO);
    escreve("Comandos do shell:\n", COR(COR_CIANO_CLARO));
    escreve("  cd, pwd  ", c); escreve("muda / mostra a pasta atual\n", d);
    escreve("  limpar   ", c); escreve("limpa a tela\n", d);
    escreve("  ps       ", c); escreve("lista os processos\n", d);
    escreve("  mem      ", c); escreve("memoria fisica livre\n", d);
    escreve("  tempo    ", c); escreve("tempo desde o boot\n", d);
    escreve("  sobre    ", c); escreve("o que e um microkernel\n", d);
    escreve("  invadir  ", c); escreve("tenta ler a memoria do nucleo (e o shell morre!)\n", d);
    escreve("  reboot   ", c); escreve("reinicia o computador\n", d);
    escreve("Programas em /bin (veja: ls /bin):\n", COR(COR_CIANO_CLARO));
    escreve("  ls cat echo mkdir rm cp cmp base64 novafetch ola codigo memoria falha filho\n", c);
    escreve("  kill sleep  (sinais: Ctrl+C interrompe o comando; nefs livro 8)\n", c);
    escreve("  janelas term relogio calculadora rabisco bloco bolas  mouse ver letras\n", c);
    escreve("      (modo grafico: bash run.sh grafico ou vnc; nefs livro 16 a 23)\n", c);
    escreve("  adduser login su sudo passwd chmod chown id whoami  (nefs livro 11)\n", c);
    escreve("  instalar-sistema instalar-boot entrar gerar-montagens desligar data\n", c);
    escreve("      (instalar o NovaEra no disco, passo a passo: nefs guia)\n", c);
    escreve("  discos particionar formatar montar desmontar  (discos; nefs livro 9 e 10)\n", c);
    escreve("  cproc qbe nefs-cpp nefs-as nefs-ld nefs-ar  (o compilador; nefs livro 4)\n", c);
    escreve("  nefs compilar  (em /usr/src/novaera: o NovaEra se compila; nefs livro 6)\n", c);
    escreve("Pipes e arquivos: ", COR(COR_CIANO_CLARO));
    escreve("ls /bin | cat    echo oi > /tmp/a    cat < /tmp/a\n", c);
}

static void cmd_ps(void)
{
    const u8 t = COR(COR_CIANO_CLARO), v = COR(COR_BRANCO);
    escreve("PID  NOME       USUARIO  PAI  ESTADO      REINICIOS\n", t);
    for (u32 pid = 0; ; pid++) {
        msg_t m;
        if (sys_tarefa_info(pid, &m) < 0) break;
        if (m.arg[0] == ESTADO_LIVRE) continue;
        char buf[11];
        escreve_coluna(num_texto(pid, buf), 5, v);
        escreve_coluna(m.texto, 11, v);
        identidade_t id;
        char quem[NOME_CONTA_MAX];
        if (pid == 0) str_copia(quem, "root", sizeof quem);   /* (pid 0 na chamada = "eu") */
        else if (sys_identidade(pid, &id) == 0) nome_usuario(id.uid, quem, sizeof quem);
        else str_copia(quem, "?", sizeof quem);
        escreve_coluna(quem, 9, v);
        escreve_coluna(num_texto(m.arg[3], buf), 5, v);
        escreve_coluna(m.arg[0] <= ESTADO_FUTEX ? ESTADOS[m.arg[0]] : "?", 12, v);
        escreve_num(m.arg[1], v);
        escreve("\n", v);
    }
}

static void cmd_mem(void)
{
    u64 r = sys_memoria();
    escreve_num((u32)(r >> 32), COR(COR_BRANCO));
    escreve(" KiB livres de ", COR(COR_CINZA_CLARO));
    escreve_num((u32)r, COR(COR_BRANCO));
    escreve(" KiB gerenciados pelo nucleo\n", COR(COR_CINZA_CLARO));
}

static void cmd_tempo(void)
{
    u32 t = sys_tempo();
    escreve("Ligado ha ", COR(COR_CINZA_CLARO));
    escreve_num(t / 100, COR(COR_BRANCO));
    escreve(" segundos (", COR(COR_CINZA_CLARO));
    escreve_num(t, COR(COR_BRANCO));
    escreve(" ticks do timer)\n", COR(COR_CINZA_CLARO));
}

static void cmd_sobre(void)
{
    const u8 d = COR(COR_CINZA_CLARO);
    escreve("NovaEra e um MICROKERNEL: o nucleo (anel 0) so cuida de memoria,\n", d);
    escreve("processos, mensagens e interrupcoes. Video, teclado, terminal,\n", d);
    escreve("arquivos, pipes e este shell sao processos separados no anel 3,\n", d);
    escreve("cada um na sua memoria, conversando por mensagens.\n", d);
}

static void cmd_invadir(void)
{
    escreve("Lendo 0x00100000, onde mora o codigo do nucleo...\n", COR(COR_AMARELO));
    u32 valor = mem_le32(0x00100000);      /* a paginação proíbe: falha de página */
    escreve("Consegui ler?! Isso nao deveria acontecer: ", COR(COR_VERMELHO_CLARO));
    escreve_num(valor, COR(COR_VERMELHO_CLARO));
    escreve("\n", COR(COR_VERMELHO_CLARO));
}

static void cmd_reboot(void)
{
    identidade_t id;
    if (sys_identidade(0, &id) == 0 && id.uid != UID_ROOT) {
        escreve("So o root reinicia (use: sudo desligar -r)\n", COR(COR_VERMELHO_CLARO));
        return;
    }
    escreve("Gravando os discos...\n", COR(COR_CINZA_CLARO));
    discos_sincronizar();
    escreve("Pedindo ao driver de teclado para reiniciar...\n", COR(COR_AMARELO));
    msg_t m;
    msg_zera(&m);
    m.tipo = MSG_REINICIAR;
    sys_enviar(PID_TECLADO, &m);
}

static void cmd_limpar(void)
{
    if (terminal_canal()) {                     /* num terminal virtual: quem limpa é a janela */
        char c[3] = { 27, TERM_LIMPA, 0 };
        escreve(c, 0);
        return;
    }
    msg_t m;
    msg_zera(&m);
    m.tipo = MSG_VIDEO_LIMPAR;
    sys_enviar(PID_VIDEO, &m);
}

static void cmd_cd(const char *destino)
{
    char abs[CAMINHO_MAX];
    if (!destino) destino = "/";
    if (caminho_absoluto(destino, abs) < 0 || arq_info(abs, 0) != ARQ_TIPO_PASTA) {
        escreve("cd: pasta nao encontrada: ", COR(COR_VERMELHO_CLARO));
        escreve(destino, COR(COR_BRANCO));
        escreve("\n", COR(COR_BRANCO));
        return;
    }
    sys_pasta(abs);
    str_copia(ambiente()->pasta, abs, CAMINHO_MAX);   /* a ulib guarda uma cópia */
}

/* ------------------------- Interpretando a linha --------------------------
 * A linha vira até 4 comandos ligados por '|'. Cada comando tem as suas
 * palavras (argv) e, opcionalmente, '<' arquivo, '>' arquivo, '>>' arquivo. */

#define LINHA_MAX     200u
#define MAX_COMANDOS  4u

typedef struct {
    char *argv[ARGV_MAX + 1];
    u32   argc;
    char *entrada;              /* < arquivo */
    char *saida;                /* > ou >> arquivo */
    u32   anexar;
} comando_t;

static char linha[LINHA_MAX + 1];

static int interpretar(comando_t *cmds, u32 *n)
{
    u32 k = 0;
    mem_zera(cmds, sizeof(comando_t) * MAX_COMANDOS);
    char *p = linha;
    char **proximo_arquivo = 0;
    for (;;) {
        while (*p == ' ' || *p == '\n') *p++ = '\0';
        if (!*p) break;
        char *palavra = p;
        while (*p && *p != ' ' && *p != '\n') p++;
        if (*p) *p++ = '\0';

        comando_t *c = &cmds[k];
        if (str_igual(palavra, "|")) {
            if (c->argc == 0 || ++k == MAX_COMANDOS) return 0;
        } else if (str_igual(palavra, "<")) {
            proximo_arquivo = &c->entrada;
        } else if (str_igual(palavra, ">") || str_igual(palavra, ">>")) {
            proximo_arquivo = &c->saida;
            c->anexar = palavra[1] == '>';
        } else if (proximo_arquivo) {
            *proximo_arquivo = palavra;
            proximo_arquivo = 0;
        } else if (c->argc < ARGV_MAX) {
            c->argv[c->argc++] = palavra;
        }
    }
    if (proximo_arquivo) return 0;                   /* "echo oi >" sem arquivo */
    *n = cmds[k].argc ? k + 1 : k;
    return *n > 0 && (*n == 1 || cmds[*n - 1].argc);
}

static int interno(comando_t *c)
{
    const char *cmd = c->argv[0];
    if      (str_igual(cmd, "ajuda"))   cmd_ajuda();
    else if (str_igual(cmd, "limpar"))  cmd_limpar();
    else if (str_igual(cmd, "ps"))      cmd_ps();
    else if (str_igual(cmd, "mem"))     cmd_mem();
    else if (str_igual(cmd, "tempo"))   cmd_tempo();
    else if (str_igual(cmd, "sobre"))   cmd_sobre();
    else if (str_igual(cmd, "invadir")) cmd_invadir();
    else if (str_igual(cmd, "reboot"))  cmd_reboot();
    else if (str_igual(cmd, "cd"))      cmd_cd(c->argv[1]);
    else if (str_igual(cmd, "pwd"))     { escreve(ambiente()->pasta, COR(COR_BRANCO)); escreve("\n", 0); }
    else return 0;
    return 1;
}

/* 'falha' = a exceção da CPU (SYS_TAREFA_INFO arg[2]), ou FALHA_NENHUMA. */
static void avisar_fim(const char *nome, long codigo, u32 falha)
{
    if (SAIDA_FOI_SINAL(codigo)) {
        u32 s = (u32)codigo & 0xFF;
        const char *sn = sinal_nome(s);
        if (s == SINAL_PIPE) return;                 /* "| head": normal, como no bash */
        if (falha < sizeof(EXCECOES) / sizeof(EXCECOES[0])) {
            escreve("[nucleo] ", COR(COR_VERMELHO_CLARO));
            escreve(nome, COR(COR_BRANCO));
            escreve(" foi encerrado: ", COR(COR_VERMELHO_CLARO));
            escreve(EXCECOES[falha], COR(COR_BRANCO));
            escreve(" (SIG", COR(COR_CINZA_CLARO));
            escreve(sn ? sn : "?", COR(COR_CINZA_CLARO));
            escreve("). O sistema continua de pe.\n", COR(COR_VERMELHO_CLARO));
            return;
        }
        escreve("[", COR(COR_CINZA_CLARO));
        escreve(nome, COR(COR_CINZA_CLARO));
        escreve(s == SINAL_INT ? " interrompido (SIG" : " encerrado pelo sinal SIG", COR(COR_CINZA_CLARO));
        if (sn) escreve(sn, COR(COR_BRANCO));
        else escreve_num(s, COR(COR_BRANCO));
        escreve(s == SINAL_INT ? ")]\n" : "]\n", COR(COR_CINZA_CLARO));
    } else if (codigo != 0) {
        escreve("[", COR(COR_CINZA_CLARO));
        escreve(nome, COR(COR_CINZA_CLARO));
        escreve(" terminou com codigo ", COR(COR_CINZA_CLARO));
        escreve_num((u32)codigo, COR(COR_BRANCO));
        escreve("]\n", COR(COR_CINZA_CLARO));
    }
}

/* Diz ao terminal quem recebe o Ctrl+C. */
/* Diz ao terminal quem recebe o Ctrl+C; devolve quem era antes. */
static u32 primeiro_plano(u32 grupo)
{
    msg_t m;
    msg_zera(&m);
    m.tipo   = TERM_GRUPO;
    m.arg[0] = grupo;
    m.arg[1] = terminal_canal();
    if (sys_chamar(PID_TERMINAL, &m) < 0 || m.tipo != MSG_OK) return 0;
    return m.arg[0];
}

static void erro_arquivo(const char *texto, const char *arquivo)
{
    escreve(texto, COR(COR_VERMELHO_CLARO));
    escreve(arquivo, COR(COR_BRANCO));
    escreve("\n", COR(COR_BRANCO));
}

/* Executa os comandos ligados por pipes e espera todos terminarem. */
static void rodar(comando_t *cmds, u32 n)
{
    long pids[MAX_COMANDOS], tubos[MAX_COMANDOS], abertos[2 * MAX_COMANDOS];
    u32 n_abertos = 0;
    u32 grupo = 0;          /* a linha toda é um grupo: o do primeiro processo */
    u32 antes = 0;          /* quem tinha o Ctrl+C antes (num /bin/sh, o su que o chamou) */
    for (u32 i = 0; i < n; i++) pids[i] = tubos[i] = -1;

    for (u32 i = 0; i < n; i++) {
        comando_t *c = &cmds[i];
        u32 ent = 0, ent_c = 0, sai = 0, sai_c = 0;    /* 0 = herda (o terminal) */

        if (i > 0) { ent = PID_TUBOS; ent_c = (u32)tubos[i - 1]; }
        if (c->entrada) {
            long a = arq_abrir(c->entrada, ARQ_MODO_LER);
            if (a < 0) {
                erro_arquivo(a == ERRO_SEM_PERMISSAO ? "Permissao negada: " : "Arquivo nao encontrado: ", c->entrada);
                break;
            }
            abertos[n_abertos++] = a;
            ent = ARQ_SERVIDOR(a); ent_c = (u32)a;
        }
        if (i + 1 < n) {
            tubos[i] = tubo_criar();
            if (tubos[i] < 0) { escreve("Sem pipes livres\n", COR(COR_VERMELHO_CLARO)); break; }
            sai = PID_TUBOS; sai_c = (u32)tubos[i];
        }
        if (c->saida) {
            long a = arq_abrir(c->saida, c->anexar ? ARQ_MODO_ANEXAR : ARQ_MODO_ESCREVER);
            if (a < 0) {
                erro_arquivo(a == ERRO_SEM_PERMISSAO ? "Permissao negada: " : "Nao consegui criar: ", c->saida);
                break;
            }
            abertos[n_abertos++] = a;
            sai = ARQ_SERVIDOR(a); sai_c = (u32)a;
        }

        /* "ola" -> /bin/ola; "./prog" ou "/tmp/prog" -> como escrito */
        char caminho[CAMINHO_MAX];
        const char *nome = c->argv[0];
        int tem_barra = 0;
        for (const char *q = nome; *q; q++) if (*q == '/') tem_barra = 1;
        if (tem_barra) {
            str_copia(caminho, nome, sizeof(caminho));
        } else {
            str_copia(caminho, "/bin/", sizeof(caminho));
            str_copia(caminho + 5, nome, sizeof(caminho) - 5);
        }

        pids[i] = executar_grupo(caminho, c->argv, ent, ent_c, sai, sai_c,
                                 grupo ? grupo : GRUPO_NOVO);
        if (pids[i] >= 0 && !grupo) {
            grupo = (u32)pids[i];
            antes = primeiro_plano(grupo);      /* o Ctrl+C agora vai para eles */
        }
        if (pids[i] < 0) {
            escreve(pids[i] == ERRO_NAO_ACHADO ? "Comando desconhecido: "
                    : pids[i] == ERRO_SEM_PERMISSAO ? "Permissao negada (sem o x): "
                    : pids[i] == ERRO_FORMATO   ? "Nao e um programa ELF valido: "
                                                : "Sem memoria ou sem vaga para: ",
                    COR(COR_VERMELHO_CLARO));
            escreve(nome, COR(COR_BRANCO));
            escreve(pids[i] == ERRO_NAO_ACHADO ? "\nDigite 'ajuda' ou 'ls /bin'.\n" : "\n",
                    COR(COR_CINZA_CLARO));
            if (i > 0 && tubos[i - 1] >= 0) {     /* ninguém vai ler: solta quem escreve */
                tubo_fechar((u32)tubos[i - 1], TUBO_LEITURA);
                tubo_fechar((u32)tubos[i - 1], TUBO_ESCRITA);
                tubos[i - 1] = -1;
            }
        }
    }

    /* Espera na ordem. O shell guarda as duas pontas de cada pipe: quando
     * quem escreve termina, ele fecha a escrita (quem lê recebe o "acabou");
     * quando quem lê termina, fecha a leitura, e o pipe é liberado. Os
     * avisos só aparecem no fim, para não se misturar com a saída. */
    long codigos[MAX_COMANDOS];
    u32 falhas[MAX_COMANDOS];
    for (u32 i = 0; i < n; i++) {
        codigos[i] = 0;
        falhas[i]  = FALHA_NENHUMA;
        if (pids[i] >= 0) {
            codigos[i] = sys_esperar((u32)pids[i]);
            msg_t m;                                /* qual exceção, se foi uma */
            if (sys_tarefa_info((u32)pids[i], &m) == 0) falhas[i] = m.arg[2];
        }
        if (tubos[i] >= 0) tubo_fechar((u32)tubos[i], TUBO_ESCRITA);
        if (i > 0 && tubos[i - 1] >= 0) tubo_fechar((u32)tubos[i - 1], TUBO_LEITURA);
    }
    if (grupo) primeiro_plano(antes);
    for (u32 i = 0; i < n; i++) if (pids[i] >= 0) avisar_fim(cmds[i].argv[0], codigos[i], falhas[i]);
    for (u32 i = 0; i < n_abertos; i++) arq_fechar((u32)abertos[i]);
}

static void executar_linha(void)
{
    comando_t cmds[MAX_COMANDOS];
    u32 n = 0;
    if (!interpretar(cmds, &n)) {
        if (n) escreve("Linha invalida (veja: ajuda)\n", COR(COR_VERMELHO_CLARO));
        return;
    }
    if (n == 1 && (str_igual(cmds[0].argv[0], "sair") || str_igual(cmds[0].argv[0], "exit"))) {
        if (do_boot) escreve("Este e o shell do sistema: ele nao sai.\n", COR(COR_CINZA_CLARO));
        else sys_sair(0);
        return;
    }
    if (n == 1 && !cmds[0].entrada && !cmds[0].saida && interno(&cmds[0])) return;
    rodar(cmds, n);
}

int main(int argc, char **argv)
{
    (void)argc; (void)argv;
    do_boot = sys_pid() == PID_SHELL;

    /* Quem sou eu: o root não aparece no prompt; os outros, sim. */
    identidade_t id;
    char quem[NOME_CONTA_MAX], maquina[32];
    quem[0] = '\0';
    str_copia(maquina, SISTEMA_PROMPT, sizeof maquina);
    if (sys_identidade(0, &id) == 0 && id.uid != UID_ROOT) nome_usuario(id.uid, quem, sizeof quem);

    /* Fui reiniciado pelo núcleo? Ele guarda quantas vezes e por quê. */
    msg_t eu;
    sys_tarefa_info((u32)sys_pid(), &eu);
    u32 reinicios = eu.arg[1], falha = eu.arg[2];

    if (do_boot) modo_init();                 /* instalado num disco? vira o init */

    /* o nome da máquina (/etc/hostname), se o sistema tiver um */
    {
        u32 tam;
        u8 *h = arq_carregar("/etc/hostname", &tam);
        if (h && tam) {
            u32 k = 0;
            while (k < tam && k + 1 < sizeof maquina && h[k] != '\n' && h[k] != '\r' && h[k] != ' ') {
                maquina[k] = (char)h[k];
                k++;
            }
            if (k) maquina[k] = '\0';
        }
        ufree(h);
    }

    if (!do_boot) {
        sinal_tratar(SINAL_INT, (void (*)(int))SINAL_IGNORAR);   /* o Ctrl+C é para os comandos */
    } else if (reinicios) {
        primeiro_plano(0);          /* o anterior pode ter morrido com um comando rodando */
        escreve("\n[nucleo] O shell anterior foi encerrado: ", COR(COR_VERMELHO_CLARO));
        escreve(falha < sizeof(EXCECOES) / sizeof(EXCECOES[0]) ? EXCECOES[falha] : "excecao",
                COR(COR_BRANCO));
        escreve(".\n[nucleo] O resto do sistema continua de pe. Shell reiniciado (",
                COR(COR_VERMELHO_CLARO));
        escreve_num(reinicios, COR(COR_BRANCO));
        escreve(").\n\n", COR(COR_VERMELHO_CLARO));
    } else {
        escreve("Shell do " SISTEMA_NOME " (processo 3, anel 3, 64 bits). Digite 'ajuda'.\n\n",
                COR(COR_CINZA_CLARO));
    }

    for (;;) {
        if (quem[0]) {
            escreve(quem, COR(COR_VERDE_CLARO));
            escreve("@", COR(COR_CINZA_CLARO));
        }
        escreve(maquina, COR(COR_CIANO_CLARO));
        escreve(":", COR(COR_CINZA_CLARO));
        escreve(ambiente()->pasta, COR(COR_AZUL_CLARO));
        escreve("> ", COR(COR_AMARELO));
        long n = ler(linha, LINHA_MAX);
        if (n == 0 && !do_boot) { escreve("\n", 0); return 0; }   /* Ctrl+D: fim */
        if (n <= 0) continue;
        linha[n] = '\0';
        executar_linha();
    }
}
