/* nlibc - unistd.h: o pedaço do POSIX que o NovaEra já tem. */
#ifndef _UNISTD_H
#define _UNISTD_H
#include <sys/types.h>
#define STDIN_FILENO  0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2
ssize_t read(int fd, void *buf, size_t n);
ssize_t write(int fd, const void *buf, size_t n);
int     close(int fd);
int     pipe(int fds[2]);
int     dup(int fd);
int     dup2(int fd, int novo);
int     unlink(const char *caminho);
int     rmdir(const char *caminho);
int     chdir(const char *caminho);
char   *getcwd(char *buf, size_t tam);
int     isatty(int fd);
pid_t   getpid(void);
pid_t   getppid(void);
_Noreturn void _exit(int codigo);
int     setpgid(pid_t pid, pid_t grupo);
pid_t   getpgid(pid_t pid);
pid_t   getpgrp(void);
pid_t   setsid(void);
unsigned sleep(unsigned segundos);
int     usleep(unsigned microssegundos);
int     pause(void);
ssize_t readlink(const char *caminho, char *buf, size_t tam);
extern char **environ;               /* o NovaEra ainda não tem variáveis de ambiente */
int     access(const char *caminho, int modo);
#define F_OK 0
#define R_OK 4
#define W_OK 2
#define X_OK 1

extern char *optarg;
extern int   optind, opterr, optopt;
int getopt(int argc, char *const argv[], const char *opcoes);
#endif
